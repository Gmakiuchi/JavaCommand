package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.actors.*;
import com.mygdx.game.MissileCommand;
import com.badlogic.gdx.graphics.g2d.freetype.*;


import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Level implements Screen {

    MissileCommand game;

    float spawnAviao=0;
    float deslocamentoLR;
    float deslocamentoRL;
    float yDesloc;
    float missileX;
    float timer;
    float gameTime;

    int missileArrayCounter = 0;
    int cityArrayCounter = 0;
    int missileDestroyed;
    int cityDestroyed = 0;
    int random;
    int missileCount;
    int nivel;
    int score;
    int baseShoot;

    boolean explosao = false;

    private FreeTypeFontGenerator ftGenerator;
    private FreeTypeFontGenerator.FreeTypeFontParameter ftParameter;
    private BitmapFont font;


    //TextField textField =  new TextField("", new Skin());
    File scoreRecords;
    FileWriter fw;

    Circle c;
    AllyMissile a;
    Explosion e;

    Sound levelStart;
    Sound gameOverSound;
    Sound shotSound;
    Sound explosionSound;
    Sound planeSound;
    ShapeRenderer shapeRenderer = new ShapeRenderer();
    Texture terrain = new Texture("terrain.png");
    Sprite terrainSprite = new Sprite(terrain);
    City cityArray[] = new City[6];
    Base baseArray[] = new Base[3];
    Missile missileArray[];
    Plane planeArray[] = new Plane[1];
    Rectangle terrainRect = new Rectangle();

    public Level(MissileCommand game, int misseis, int nivel, int score){
        this.game = game;
        missileCount = misseis;
        this.nivel= nivel;
        this.score = score;
    }

    @Override
    public void show() {
        ftGenerator = new FreeTypeFontGenerator(Gdx.files.internal("Minecraft.ttf"));
        ftParameter =  new FreeTypeFontGenerator.FreeTypeFontParameter();

        scoreRecords = new File(String.valueOf(Gdx.files.internal("scoreRecords.txt")));



        ftParameter.color = Color.BLACK;
        font = ftGenerator.generateFont(ftParameter);

        gameOverSound = Gdx.audio.newSound(Gdx.files.internal("MixKit_GameOver.wav"));
        shotSound = Gdx.audio.newSound(Gdx.files.internal("MixKit_Shot.wav"));
        planeSound = Gdx.audio.newSound(Gdx.files.internal("101SB_Aviao.mp3"));
        explosionSound = Gdx.audio.newSound(Gdx.files.internal("MixKit_BombExplosion.mp3"));
        levelStart = Gdx.audio.newSound(Gdx.files.internal("101SB_InicioFase.mp3"));

        baseShoot = 0;
        random =  MathUtils.random(1,2);
        deslocamentoLR = -25;
        deslocamentoRL = Gdx.graphics.getWidth();
        yDesloc = Gdx.graphics.getHeight()+4;
        missileArray = new Missile[missileCount];
        //populando array de cidade
        cityArray[0] = new City(92);
        cityArray[1] = new City(160);
        cityArray[2] = new City(220);
        cityArray[3] = new City(352);
        cityArray[4] = new City(432);
        cityArray[5] = new City(503);
        //populando array de base
        baseArray[0] = new Base(5, 72);
        baseArray[1] = new Base(282,55);
        baseArray[2] = new Base(567,72);
        //array aviao
        planeArray[0] = new Plane();

        System.out.println(baseShoot);

        for(int contadorMisseis=0;contadorMisseis<missileCount;contadorMisseis++) {
            missileX = MathUtils.random(4,Gdx.graphics.getWidth()+4);
            int alvo = MathUtils.random(0, 5);
            missileArray[contadorMisseis] = new Missile(missileX, Gdx.graphics.getHeight()+(contadorMisseis*100), alvo);
            missileArray[contadorMisseis].drawMissile();
        }
        missileDestroyed = missileArray.length;
        cityDestroyed = cityArray.length;

    }


    @Override
    public void render(float delta) {
        gameTime += delta;
        game.batch.begin();
        ftParameter.size = 50;
        font.draw(game.batch, "LEVEL: " + nivel, 5, Gdx.graphics.getHeight()-5);

        ScreenUtils.clear(new Color(Color.SKY));
        //ScreenUtils.clear(163,207,255,1);
        float velocidade = (float)1;


        game.batch.draw(terrainSprite, 0 ,0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight()/8); // Desenha o terreno
        ftParameter.size = 15;
        font.draw(game.batch, "Score: " + score, Gdx.graphics.getWidth()/2 - 25, Gdx.graphics.getHeight()-5); // Mostra a pontuação na tela
        terrainRect.setSize(Gdx.graphics.getWidth(), 62);
        terrainRect.setPosition(0,0);
        game.batch.end();

        //Sai do jogo
        if(Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)){
            game.setScreen(new MainMenuScreen(game, 5));
        }

        //Movimentação do missil aliado
        if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT) && a==null && Gdx.input.getY() < (Gdx.graphics.getHeight() - 80)){

            //timer = 0;
            shotSound.play(.2f);//executa o som de tiro

            a = new AllyMissile(baseArray[baseShoot], Gdx.input.getX(), Gdx.input.getY()); // Cria o missil aliado

            c = new Circle(a.getInputX(),a.getInputY(), 3f); //Cria um circulo no destino do missil aliado para fazer a explosão


            baseShoot++; //Faz o incremento da base que ira disparar

            if(baseShoot == 3){ //Posicao da base que ira disparar
                baseShoot=0;
            }

        }

        if(a!=null){
            a.movement(); //movimentação do míssil
            if (Intersector.overlaps(c, a.getBoundRect())){
                timer = 0.75f;
                explosao = true;

            }
            //System.out.println(timer);
            if (explosao) {//Verifica se o missil chegou no destino
                a.setDestroyed();
                a.setPosY(a.getPosY() + 20);
                timer -= delta;
            }
                if (timer > 0){
                    e =  new Explosion(c);
                    e.animation(delta);
                }
            if (timer < 0){

                a = null;
                explosao = false;
                e = null;
                timer =0;

            }
        }

        for (Missile m :
                missileArray) {
            if(e!=null&& !m.isDestroyed() && Intersector.overlaps(e.getExplosão(), m.getBoundRect())){
                m.setDestroyed();
                explosionSound.play(.2f);
                score+=25;
            }
        }

        //Desenha as cidades
        for (City tempCity : cityArray) {
            tempCity.drawCity();
            //mostra caixa de colisao
            if(Gdx.input.isKeyPressed(Input.Keys.F3)){
                shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
                shapeRenderer.rect(tempCity.getPosX(), tempCity.getPosY(), tempCity.getWidth(), tempCity.getHeight());
                shapeRenderer.setColor(Color.MAGENTA);
                shapeRenderer.end();
            }
        }

        //Desenha as bases
        for (Base tempBase: baseArray) {
            tempBase.drawBase();
        }

        //Desenha os Misseis
        for (int i = 0; i <missileCount; i++){
            if (missileArray[i]!=null && !missileArray[i].isDestroyed()){
                missileArray[i].movement(cityArray[missileArray[i].getAlvo()], (float) (1+(nivel*.1)));
            }
            if(Gdx.input.isKeyPressed(Input.Keys.F3)){

                //caixa de colisao dos misseis
                if (missileArray[i]!=null && !missileArray[i].isDestroyed()) {
                    shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
                    shapeRenderer.rect(missileArray[i].getPosX(), missileArray[i].getPosY(), missileArray[i].getWidth(), missileArray[i].getHeight());
                    shapeRenderer.setColor(Color.MAGENTA);
                }
                shapeRenderer.end();
            }
        }


        //colisao Missil/Cidade
        for (Missile m : missileArray) {
            for (City c : cityArray) {
                if (m!=null && c.isDestroyed()==false){
                    if (m.getBoundRect().overlaps(c.getBoundRect())){
                        m.setDestroyed();
                        c.setDestroyed();
                        explosionSound.play(0.2f);
                    }
                }
                if (m!=null && c.isDestroyed()==true){
                    if (m.getBoundRect().overlaps(c.getBoundRect())){
                        m.setDestroyed();

                    }
                }
            }
            //Colisao Missil/Base
            for(Base b : baseArray){
                if(m!=null){
                    if (m.getBoundRect().overlaps(b.getBoundRect())){
                        m.setDestroyed();
                    }
                }
            }
        }


        //Define qual lado do sprite do aviao
        if(planeArray[0]!=null){
            planeArray[0].setPlaneTexture(random);
        }

        //tempo de Spawn do aviao
            spawnAviao += delta;

        if ((int)spawnAviao>=(3*nivel)){
            if (random==1){
                deslocamentoRL-=velocidade;
                if (planeArray[0] != null) {
                    planeArray[0].drawPlane(random, deslocamentoRL);
                }
                if(deslocamentoRL < 0){
                    planeArray[0] = null;
                }
            }else{
                deslocamentoLR += velocidade;
                if (planeArray[0] != null){
                    planeArray[0].drawPlane(random,deslocamentoLR);
                }
                if(deslocamentoLR > Gdx.graphics.getWidth()){
                    planeArray[0] = null;

                }
            }
        }


            if(e!=null && planeArray[0]!=null && !planeArray[0].isDestroyed() && Intersector.overlaps(e.getExplosão(), planeArray[0].getBoundRect())){
                planeArray[0].setDestroyed();
                score+=50;
                planeArray[0] = null;
            }

        //caixa de colisao do avião
        if(Gdx.input.isKeyPressed(Input.Keys.F3)){
            if (planeArray[0]!=null){
                shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
                shapeRenderer.rect(planeArray[0].getPosX(), planeArray[0].getPosY(), planeArray[0].getWidth(), planeArray[0].getHeight());
                shapeRenderer.setColor(Color.MAGENTA);
                shapeRenderer.end();
            }

        }



        if(missileArray[missileArrayCounter].isDestroyed()){ //Verifica se ainda há misseis
            missileDestroyed--;
            missileArrayCounter++;
        }
        if(cityArrayCounter<cityArray.length){ //Verifica se ainda há Cidades
            if (cityArray[cityArrayCounter].isDestroyed()){
                cityDestroyed--;
                cityArrayCounter++;
            }
        }


        if (missileDestroyed == 0 && cityDestroyed > 0){ //Se nao há misseis mas há cidades = Prox Nivel
            for (City c :
                    cityArray) {
                if (!c.isDestroyed()){
                    score += 100;
                }
            }
            game.setScreen(new Level(game, (int) (missileCount*1.2),nivel+1, score));
            levelStart.play(.2f);
        }

       //CONDIÇÃO DE DERROTA
        if (cityDestroyed == 0){ //Se nao há cidades = Derrota
        //if(Gdx.input.isButtonJustPressed(Input.Buttons.RIGHT)){

            try {
                fw = new FileWriter(scoreRecords, true);
                fw.write(score + "\n");
                fw.close();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            game.setScreen(new ScoreScreen(game));
            gameOverSound.play();
        }

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }





}
