package com.mygdx.game.actors;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class Base extends GameObject{
    SpriteBatch batch = new SpriteBatch();
    int posX;
    int posY = 60;
    int height = 13;
    int width;

    public Base(int x, int width) {
        this.posX = x;
        this.width = width;
        setTexture();
    }


    @Override
    protected void setTexture() {
        this.texture = new Texture("terrain_fire_base_12.png");
    }

    @Override
    public Rectangle getBoundRect() {
        this.setBoundRect(posX, posY, width, height);
        return super.boundRect;
    }

    public int getPosX() {
        return posX;
    }

    public int getPosY() {
        return posY;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

    public void drawBase(){
        batch.begin();
        batch.draw(getTexture(), getPosX(), getPosY(), getWidth(), getHeight());
        batch.end();
    }

}
