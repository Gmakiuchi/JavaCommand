package com.mygdx.game;

import com.badlogic.gdx.audio.Sound;
import com.mygdx.game.screens.MainMenuScreen;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Cursor;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class MissileCommand extends Game {

	public SpriteBatch batch;
	Pixmap pixmap;
	int xHS;
	int yHS;


	@Override
	public void create() {
		batch = new SpriteBatch();
		this.setScreen(new MainMenuScreen(this, 0));
		pixmap = new Pixmap(Gdx.files.internal("target_sight.png"));

	}

	@Override
	public void render(){

		yHS = pixmap.getHeight()/2;
		xHS = pixmap.getWidth()/2;

		Cursor cursor = Gdx.graphics.newCursor(pixmap,xHS,yHS);
		Gdx.graphics.setCursor(cursor);
		//pixmap.dispose();
		super.render();
	}
}
