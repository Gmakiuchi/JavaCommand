package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.MissileCommand;

public class MainMenuScreen implements Screen {

    MissileCommand game;
    Texture playBtn;
    Texture inversePlayBtn;
    Texture creditsBtn;
    Texture inverseCredBtn;
    Texture exitBtn;
    Texture inverseExitBtn;
    Texture scoreBtn;
    Texture inverseScoreBtn;
    Sound levelStart;
    float count;
    int gameHeight = Gdx.graphics.getHeight();
    int gameWidth = Gdx.graphics.getWidth();

    public MainMenuScreen(MissileCommand game, int x) {
        count=x;
        this.game = game;
        inversePlayBtn = new Texture("start_btn.png");
        playBtn = new Texture("inverse_start_btn.png");
        inverseExitBtn = new Texture("exit_btn.png");
        exitBtn = new Texture("inverse_exit_btn.png");
        inverseCredBtn = new Texture("credits_btn.png");
        creditsBtn = new Texture("inverse_credits_btn.png");
        scoreBtn =  new Texture("score_btn.png");
        inverseScoreBtn = new Texture("inverse_score_btn.png");
    }

    @Override
    public void show() {
        levelStart = Gdx.audio.newSound(Gdx.files.internal("101SB_InicioFase.mp3"));
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0,0,0,1);
        game.batch.begin();

        count += delta;
        if(count<3){
            Texture intro = new Texture("intro.png");
            game.batch.draw(intro,-25,0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        }else {

            int playX = gameWidth / 2 - playBtn.getWidth() / 2;
            int playY = gameHeight / 2 - playBtn.getHeight() / 2 + 75;
            int credX = gameWidth / 2 - creditsBtn.getWidth() / 2;
            int credY = gameHeight / 2 - creditsBtn.getHeight() / 2;
            int scoreX = gameWidth / 2 - scoreBtn.getWidth()/2;
            int scoreY = gameHeight / 2 - scoreBtn.getHeight() / 2 - 75;
            int exitX = gameWidth / 2 - creditsBtn.getWidth() / 2;
            int exitY = gameHeight / 2 - exitBtn.getHeight() / 2 - 150;

            //Play Button
            if (Gdx.input.getX() < playX + playBtn.getWidth() && Gdx.input.getX() > playX
                    && gameHeight - Gdx.input.getY() < playY + playBtn.getHeight() && gameHeight - Gdx.input.getY() > playY) {
                game.batch.draw(inversePlayBtn, gameWidth / 2 - playBtn.getWidth() / 2, gameHeight / 2 - playBtn.getHeight() / 2 + 75);
                if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
                    game.setScreen(new Level(game, 15, 1, 0));
                    levelStart.play(.2f);
                }
            } else {
                game.batch.draw(playBtn, gameWidth / 2 - playBtn.getWidth() / 2, gameHeight / 2 - playBtn.getHeight() / 2 + 75);
            }
            //Credits Button
            if (Gdx.input.getX() < credX + creditsBtn.getWidth() && Gdx.input.getX() > credX
                    && Gdx.input.getY() < credY + creditsBtn.getHeight() && Gdx.input.getY() > credY) {
                game.batch.draw(inverseCredBtn, gameWidth / 2 - creditsBtn.getWidth() / 2, gameHeight / 2 - creditsBtn.getHeight() / 2);
                if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
                    game.setScreen(new CreditsScreen(game));
                }
            } else {
                game.batch.draw(creditsBtn, gameWidth / 2 - creditsBtn.getWidth() / 2, gameHeight / 2 - creditsBtn.getHeight() / 2);
            }

            //Score Button
            if (Gdx.input.getX() < scoreX + scoreBtn.getWidth() && Gdx.input.getX() > scoreX
                    && gameHeight - Gdx.input.getY() < scoreY + scoreBtn.getHeight() && gameHeight - Gdx.input.getY() > scoreY) {
                game.batch.draw(scoreBtn, gameWidth / 2 - scoreBtn.getWidth() / 2, gameHeight / 2 - scoreBtn.getHeight() / 2 - 75);
                if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
                    game.setScreen(new ScoreScreen(game));
                }
            } else {
                game.batch.draw(inverseScoreBtn, gameWidth / 2 - scoreBtn.getWidth() / 2, gameHeight / 2 - scoreBtn.getHeight() / 2 - 75);
            }

            //Exit Button
            if (Gdx.input.getX() < exitX + exitBtn.getWidth() && Gdx.input.getX() > exitX
                    && gameHeight - Gdx.input.getY() < exitY + exitBtn.getHeight() && gameHeight - Gdx.input.getY() > exitY) {
                game.batch.draw(inverseExitBtn, gameWidth / 2 - exitBtn.getWidth() / 2, gameHeight / 2 - exitBtn.getHeight() / 2 - 150);
                if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
                    Gdx.app.exit();
                }
            } else {
                game.batch.draw(exitBtn, gameWidth / 2 - creditsBtn.getWidth() / 2, gameHeight / 2 - exitBtn.getHeight() / 2 - 150);
            }
        }
        game.batch.end();
     }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
