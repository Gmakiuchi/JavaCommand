package com.mygdx.game.actors;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;


public class AllyMissile extends GameObject{

    private int inputX, inputY;
    private int initialX, initialY;
    private SpriteBatch batch = new SpriteBatch();
    private float posX, posY;



    public AllyMissile(Base b, int inputX, int inputY) {
        this.inputX = inputX;
        this.inputY =  Gdx.graphics.getHeight() - inputY;
        setTexture();
        initialX = b.getPosX() + b.getWidth()/2;
        initialY = b.getPosY() + b.getHeight();


        sprite = new Sprite(texture);
        sprite.setPosition(initialX , initialY);
        sprite.setSize(4,4);
        setBoundRect(initialX, initialY, (int) (sprite.getWidth()),(int) (sprite.getHeight()));
    }

    public void setPosY(float posY) {
        this.posY = posY;
    }

    public int getInputX() {
        return inputX;
    }

    public int getInputY() {
        return inputY;
    }

    public int getInitialX() {
        return initialX;
    }

    public int getInitialY() {
        return initialY;
    }

    public void setDestroyed(){
        destroyed = true;
    }

    public boolean isDestroyed(){
        return destroyed;
    }

    @Override
    protected void setTexture() {
            texture = new Texture("missile_ally.png");
    }

    @Override
    public Rectangle getBoundRect() {
        this.setBoundRect(this.posX,this.posY,texture.getWidth(), texture.getHeight());
        return boundRect;
    }

    public float getPosY() {
        return posY;
    }

    public void movement(){
        batch.begin();
        float deltaX;
        float deltaY;

        deltaX = getInputX() - getInitialX();
        deltaY = getInputY() - getInitialY();

        float hipotenusa = (float)Math.sqrt (Math.pow(deltaX, 2) + Math.pow(deltaY,2));

        float sin = (deltaX/hipotenusa);
        float cos = (deltaY/hipotenusa);


            getSprite().translate(sin * 7, cos * 7);



        this.posX = getSprite().getX();
        this.posY = getSprite().getY();

        getBoundRect();
        if(!isDestroyed()) {
            getSprite().draw(batch);
        }
        batch.end();
    }
}
