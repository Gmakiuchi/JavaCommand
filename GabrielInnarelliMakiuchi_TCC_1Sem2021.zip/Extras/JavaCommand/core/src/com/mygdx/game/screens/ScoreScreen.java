package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.MissileCommand;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class ScoreScreen implements Screen {

    MissileCommand game;

    File scoreFile;
    Scanner scanner;
    ArrayList<Integer> resultList = new ArrayList<>();
    ArrayList<Integer> scoreList = new ArrayList<>();

    int gameHeight = Gdx.graphics.getHeight();
    int gameWidth = Gdx.graphics.getWidth();

    Texture voltarBtn = new Texture(Gdx.files.internal("voltar_btn.png"));
    Texture inverseVoltarBtn = new Texture(Gdx.files.internal("inverse_voltar_btn.png"));

    private FreeTypeFontGenerator ftGenerator;
    private FreeTypeFontGenerator.FreeTypeFontParameter ftParameter;
    private BitmapFont font;


    public ScoreScreen(MissileCommand game) {
        this.game = game;
    }

    @Override
    public void show() {
        ftGenerator = new FreeTypeFontGenerator(Gdx.files.internal("Minecraft.ttf"));
        ftParameter =  new FreeTypeFontGenerator.FreeTypeFontParameter();

        ftParameter.color = Color.WHITE;
        ftParameter.size = 30;
        font = ftGenerator.generateFont(ftParameter);
        scoreFile = new File(String.valueOf(Gdx.files.internal("scoreRecords.txt")));

        try {
            scanner =  new Scanner(scoreFile);
            while (scanner.hasNext()){
                resultList.add(scanner.nextInt());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for (int i=0; i < resultList.size(); i++){

            scoreList.add(resultList.get(i));

            Collections.sort(scoreList, Collections.<Integer>reverseOrder());

        }
        for (int i=0;i<scoreList.size();i++){

            System.out.println(scoreList.get(i));
        }

    }

    @Override
    public void render(float delta) {

        ScreenUtils.clear(Color.BLACK);
        game.batch.begin();

        font.draw(game.batch, "HIGHSCORES:", Gdx.graphics.getWidth()/2 - 100, Gdx.graphics.getHeight()/2+130);
        font.draw(game.batch, scoreList.get(0).toString(), Gdx.graphics.getWidth()/2 - 20, Gdx.graphics.getHeight()/2+50);
        font.draw(game.batch, scoreList.get(1).toString(), Gdx.graphics.getWidth()/2 - 20, Gdx.graphics.getHeight()/2);
        font.draw(game.batch, scoreList.get(2).toString(), Gdx.graphics.getWidth()/2 - 20, Gdx.graphics.getHeight()/2-50);

        int voltarX = gameWidth-100-voltarBtn.getWidth();
        int voltarY = gameHeight-440;

        if(Gdx.input.getX() < voltarX + voltarBtn.getWidth() && Gdx.input.getX() > voltarX
                && gameHeight - Gdx.input.getY() < voltarY + voltarBtn.getHeight() && gameHeight - Gdx.input.getY() > voltarY){
            game.batch.draw(inverseVoltarBtn, voltarX, voltarY);
            if(Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)){
                game.setScreen(new MainMenuScreen(game,5));
            }
        }else{
            game.batch.draw(voltarBtn, voltarX, voltarY);
        }

        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
