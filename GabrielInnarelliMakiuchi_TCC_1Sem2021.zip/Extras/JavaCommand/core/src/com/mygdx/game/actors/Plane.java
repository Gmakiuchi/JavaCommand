package com.mygdx.game.actors;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class Plane extends GameObject{
    SpriteBatch batch = new SpriteBatch();
    Sprite planeSprite;
    //inicializa o aviao fora da tela
    float posX = -100;
    int posY = -100;
    int width;
    int height;
    int side;

    public boolean isDestroyed() {
        return destroyed;
    }

    public void setDestroyed() {
        this.destroyed = true;
    }

    public float getPosX() {
        return posX;
    }

    public int getPosY() {
        return posY;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void setPlaneTexture(int x){
        if(x==1){
            this.texture = new Texture("enemy_plane_left2.png");
            width = 25;
            height = 12;
            posY = Gdx.graphics.getHeight()-100;
            side = x;
        }else{
            this.texture =  new Texture("enemy_plane_right2.png");
            width = 25;
            height = 12;
            posY = Gdx.graphics.getHeight()-100;
            side = x;
        }
    }

    public int getSide() {
        return side;
    }

    public void drawPlane(int rnd, float deslocamento){
        if(this.texture!=null){
            this.planeSprite = new Sprite(this.texture);
            this.planeSprite.setSize(width, height);

        }
        if(rnd==1){

            this.posX = Gdx.graphics.getWidth();
            move(deslocamento);
            getBoundRect();
        }else{

            this.posX = -(this.width);
            move(deslocamento);
            getBoundRect();
        }
    }

    protected void move(float deslocamento){
        batch.begin();
        planeSprite.setPosition(deslocamento, posY);
        this.posX = deslocamento;
        getBoundRect();
        planeSprite.draw(batch);
        batch.end();
    }

    @Override
    protected void setTexture() {

    }

    @Override
    public Rectangle getBoundRect() {
        this.setBoundRect(posX, posY, width,height);
        return super.boundRect;
    }
}
