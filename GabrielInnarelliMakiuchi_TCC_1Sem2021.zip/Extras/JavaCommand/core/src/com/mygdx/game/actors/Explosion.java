package com.mygdx.game.actors;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Circle;

public class Explosion {

    Circle explosão;

    ShapeRenderer renderer = new ShapeRenderer();

    public Explosion(Circle explosão) {
        this.explosão = explosão;
    }

    public void animation(float delta){
            explosão.setRadius(17.5f);
            renderer.begin(ShapeRenderer.ShapeType.Filled);
            renderer.setColor(Color.YELLOW);
            renderer.circle(explosão.x, explosão.y, explosão.radius);
            renderer.end();
            renderer.begin(ShapeRenderer.ShapeType.Line);
            renderer.setColor(Color.RED);
            renderer.circle(explosão.x, explosão.y, explosão.radius);
            renderer.end();
    }


    public Circle getExplosão() {
        return explosão;
    }
}
