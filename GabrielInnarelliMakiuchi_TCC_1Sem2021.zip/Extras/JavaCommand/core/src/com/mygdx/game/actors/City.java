package com.mygdx.game.actors;


import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;


public class City extends GameObject{

    SpriteBatch batch = new SpriteBatch();
    private int posX;
    private int posY;
    private int width = 35;
    private int height = 20;

    public City(int posX) {
        this.posX = posX;
        this.posY = 60;
        this.setTexture();
    }

    public boolean isDestroyed(){
        return this.destroyed;
    }

    public void setDestroyed(){
        this.texture = new Texture("cityDestroida.png");
        super.destroyed = true;
    }

    public int getPosX() {
        return posX;
    }

    public int getPosY() {
        return posY;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void drawCity( ){
        batch.begin();
        batch.draw(getTexture(), getPosX(), getPosY(), getWidth(), getHeight());
        batch.end();
    }


    @Override
    public void setTexture() {
        this.texture = new Texture("cityteste.png");
    }

    @Override
    public Rectangle getBoundRect() {
        this.setBoundRect(posX, posY, width, height);

        return super.boundRect;
    }
}
