package com.mygdx.game.actors;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;


public class Missile extends GameObject {
    SpriteBatch batch = new SpriteBatch();
    Sprite missileSprite;

    float posXinicial;
    float posYinicial;
    float posX;
    float posY;
    int alvo;

    public Missile( float x, float y, int alvo){
        this.alvo = alvo;
        destroyed = false;
        setTexture();
        this.missileSprite = new Sprite(texture);
        missileSprite.setSize(4,4);
        setBoundRect(x,y, texture.getWidth(), texture.getHeight());
        this.posXinicial = x;
        this.posYinicial = y;
        this.posX = x;
        this.posY = y;
    }

    public void setDestroyed(){ this.destroyed = true;   }

    @Override
    public boolean isDestroyed(){
        return destroyed;
    }

    public float getPosXinicial() {
        return posXinicial;
    }

    public float getPosYinicial() {
        return posYinicial;
    }

    public float getPosX() {
        return posX;
    }

    public float getPosY() {
        return posY;
    }

    public int getAlvo() {
        return alvo;
    }

    public int getWidth(){
        return texture.getWidth();
    }

    public int getHeight(){
        return texture.getHeight();
    }

    public Sprite getMissileSprite() {
        return missileSprite;
    }

    public void drawMissile(){
        batch.begin();
        missileSprite.setSize(4, 4);
        missileSprite.setPosition(getPosX(), getPosY());
        missileSprite.setRotation(270);
        missileSprite.draw(batch);
        batch.end();
    }

    public void movement(City city, float velocidade){
        batch.begin();
        float deltaX;
        float deltaY;

        deltaX = getPosXinicial() - (city.getPosX() + city.getWidth() / 2);
        deltaY = (city.getPosY() + city.getHeight()) - Gdx.graphics.getHeight();

        float hipotenusa = (float)Math.sqrt (Math.pow(deltaX, 2) + Math.pow(deltaY,2));

        float sin = -(deltaX/hipotenusa) * velocidade;
        float cos = deltaY/hipotenusa * velocidade;

        if(posY > Gdx.graphics.getHeight()){
            getMissileSprite().translate(0, cos*velocidade);
        }else{
            getMissileSprite().translate(sin*velocidade, cos*velocidade);
        }



        this.posX = missileSprite.getX();
        this.posY = missileSprite.getY();
        getBoundRect();
        missileSprite.draw(batch);
        batch.end();


        //float deltaX = posXinicial - (city.getPosX()+city.getWidth()/2);
        //float deltaY = (city.getPosY() + city.getHeight()) - posYinicial;
        //missileSprite.translate(sin*.1f, cos*.1f);

    }
    @Override
    protected void setTexture() {
        texture = new Texture("enemy_missile.png");
    }

    @Override
    public Texture getTexture(){
        return this.texture;
    }

    /*public Rectangle getRect(Missile m){
        Rectangle r = new Rectangle();
        r.setSize(m.getWidth(),m.getHeight());
        r.setPosition(m.getPosX(), m.getPosY());
        return r;
    } */

    @Override
    public Rectangle getBoundRect() {
        this.setBoundRect(this.posX,this.posY,texture.getWidth(), texture.getHeight());

        return super.boundRect;
    }
}
