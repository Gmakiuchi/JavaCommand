package com.mygdx.game.actors;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Rectangle;

public abstract class GameObject {

     Texture texture;
     Sprite sprite;
     Rectangle boundRect;
     boolean destroyed;

    protected boolean isDestroyed() {
        return destroyed;
    }

    protected void setDestroyed(boolean destroyed) {
        this.destroyed = destroyed;
    }

    protected Texture getTexture() {
        return texture;
    }

    protected abstract void setTexture();


    protected Sprite getSprite() {
        return sprite;
    }

    protected void setSprite(Sprite sprite) {
        this.sprite = sprite;
    }

    protected abstract Rectangle getBoundRect();

    protected void setBoundRect(float x, float y, int width, int height){
        boundRect = new Rectangle(x, y, width, height);
        //this.boundRect.setPosition(x, y);
        //this.boundRect.setSize(width, height);
    }
}

