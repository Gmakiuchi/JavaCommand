package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;
import com.mygdx.game.MissileCommand;

public class CreditsScreen implements Screen {
    MissileCommand game;
    int gameHeight = Gdx.graphics.getHeight();
    int gameWidth = Gdx.graphics.getWidth();
    Texture orientado = new Texture("orientado.png");
    Texture nome = new Texture("meuNome.png");
    Texture orientador = new Texture("orientador.png");
    Texture nomeOrientador = new Texture("profFabio.png");
    Texture coorientador = new Texture("coorientador.png");
    Texture nomeCoorientador = new Texture("profJoice.png");
    Texture voltarBtn = new Texture("voltar_btn.png");
    Texture inverseVoltarBtn = new Texture("inverse_voltar_btn.png");

    public CreditsScreen(MissileCommand game) {
        this.game = game;
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0,0,0,1);

        game.batch.begin();
        game.batch.draw(orientado, gameWidth/6, gameHeight-100);
        game.batch.draw(nome, gameWidth/6, gameHeight-140);
        game.batch.draw(orientador, gameWidth/6, gameHeight-200);
        game.batch.draw(nomeOrientador, gameWidth/6, gameHeight-240);
        game.batch.draw(coorientador, gameWidth/6, gameHeight-300);
        game.batch.draw(nomeCoorientador, gameWidth/6, gameHeight-340);

        int voltarX = gameWidth-100-voltarBtn.getWidth();
        int voltarY = gameHeight-440;
        if(Gdx.input.getX() < voltarX + voltarBtn.getWidth() && Gdx.input.getX() > voltarX
                && gameHeight - Gdx.input.getY() < voltarY + voltarBtn.getHeight() && gameHeight - Gdx.input.getY() > voltarY){
            game.batch.draw(inverseVoltarBtn, voltarX, voltarY);
            if(Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)){
                game.setScreen(new MainMenuScreen(game,5));
            }
        }else{
            game.batch.draw(voltarBtn, voltarX, voltarY);
        }
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
